# AI-Powered Resume Screening & Candidate Ranking System

An end-to-end NLP pipeline that parses resumes, extracts skills/entities,
scores each candidate against a job description using TF-IDF + Cosine
Similarity, ranks candidates, and presents results through a Streamlit
dashboard with exportable reports.

## Why this structure?

The project follows **clean architecture** principles: each layer has a
single responsibility and depends only on the layers "below" it, never
above. This keeps the ML/NLP core (`src/`) completely independent of the
UI (`frontend/`) — you could swap Streamlit for FastAPI or a CLI without
touching a single line of parsing/scoring logic.

```
                       ┌───────────────────────┐
                       │   frontend/ (Streamlit) │  ← presentation layer
                       └───────────┬───────────┘
                                   │ calls
                       ┌───────────▼───────────┐
                       │   scripts/ (orchestration)│  ← pipeline entrypoints
                       └───────────┬───────────┘
                                   │ uses
        ┌───────────┬─────────────┼─────────────┬───────────┐
        ▼           ▼             ▼             ▼           ▼
   parsing/   preprocessing/  extraction/   features/   similarity/
                                                              │
                                                              ▼
                                                          ranking/
                                                              │
                                                              ▼
                                                         reporting/
        (all of the above are pure, UI-agnostic Python — the "domain" layer)
                                   │
                                   ▼
                       config/  +  utils/   ← cross-cutting concerns
```

## Folder Map

| Folder | Purpose |
|---|---|
| `config/` | All tunable settings (paths, weights, skills taxonomy) — never hardcode these in code |
| `data/` | Raw → interim → processed data lake for resumes and job descriptions |
| `src/parsing/` | Extract raw text out of PDF/DOCX resumes |
| `src/preprocessing/` | Clean, tokenize, normalize text (NLTK/spaCy) |
| `src/extraction/` | Pull structured signal out of raw text: skills, entities, sections |
| `src/features/` | Turn text into numeric features (TF-IDF, future embeddings) |
| `src/similarity/` | Compute resume ↔ job-description similarity scores |
| `src/ranking/` | Combine scores into a final ranked candidate list |
| `src/reporting/` | Generate PDF/CSV reports per candidate or per job |
| `src/bias_detection/` | (future) Fairness / bias auditing of rankings |
| `src/feedback/` | (future) Recruiter feedback loop to retrain/re-weight the model |
| `src/llm_integration/` | (future) LLM-based re-ranking, summarization, Q&A |
| `src/utils/` | Shared helpers: logging, file IO, constants |
| `models/` | Serialized vectorizers/trained models (git-ignored, regenerable) |
| `notebooks/` | Exploratory analysis only — never production logic |
| `frontend/` | Streamlit multipage dashboard |
| `outputs/` | Generated ranked lists, reports, logs (git-ignored) |
| `tests/` | Unit tests, mirrors `src/` package layout |
| `scripts/` | End-to-end pipeline runner, environment setup |
| `docs/` | Architecture notes, API reference |

See `docs/architecture.md` for a deeper explanation of the design and
`docs/api_reference.md` for module-level docs as they're implemented.

## Quickstart

```bash
# 1. Clone and enter the project
git clone <your-repo-url> resume-screening-system
cd resume-screening-system

# 2. Set up environment (creates venv, installs deps, downloads NLTK/spaCy data)
bash scripts/setup_env.sh

# 3. Activate the environment
source venv/bin/activate        # Windows: venv\Scripts\activate

# 4. Drop resumes into data/raw/resumes/ and a JD into data/raw/job_descriptions/

# 5. Run the pipeline end-to-end
python scripts/run_pipeline.py

# 6. Launch the dashboard
streamlit run frontend/app.py
```

## Roadmap (structure already supports these)

- [ ] Named Entity Recognition — `src/extraction/entity_extractor.py`
- [ ] LLM integration (summarization / re-ranking) — `src/llm_integration/`
- [ ] Bias / fairness detection — `src/bias_detection/`
- [ ] Recruiter feedback loop — `src/feedback/`
